/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Triangulo { 
    GL gl;
    float x,y,z;
    float rx,ry,rz;
    float w,h,d;
    float r,g,b,a;
    GLUT glut=new GLUT();

    public Triangulo(GL gl, float x, float y, float z, float rx, float ry, float rz, float w, float h, float d, float r, float g, float b) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.w = w;
        this.h = h;
        this.d = d;
        this.r = r;
        this.g = g;
        this.b = b;
    }
    public void display(){
        gl.glPushMatrix();
        gl.glColor3f(this.r, this.g,this.b);
        gl.glTranslatef(this.x, this.y, this.z);
        gl.glRotatef(this.rx, 1, 0, 0);
        gl.glRotatef(this.ry, 0, 1, 0);
        gl.glRotatef(this.rz, 0, 0, 1);
        gl.glScalef(this.w, this.h, this.d);
        gl.glBegin(GL.GL_TRIANGLES);
        //Cara FrontalG
        
            gl.glVertex3f(0,0,0);
            gl.glVertex3f(1,0,0);
            gl.glVertex3f(1,1,0);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Derecha
            
            gl.glVertex3f(1,0,0);
            gl.glVertex3f(1,0,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,0);
        gl.glEnd();
        gl.glBegin(GL.GL_TRIANGLES);
        //Cara Trasera
            gl.glVertex3f(0,0,-1);
            gl.glVertex3f(1,0,-1);
            gl.glVertex3f(1,1,-1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Izquierda
        gl.glColor3f(this.r+0.15f, this.g+0.15f,this.b+0.15f);
            gl.glVertex3f(0,0,0);
            gl.glVertex3f(0,0,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,0);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Inferior
            gl.glVertex3f(0,0,0);
            gl.glVertex3f(0,0,-1);
            gl.glVertex3f(1,0,-1);
            gl.glVertex3f(1,0,0);
        gl.glEnd();
        gl.glPopMatrix();
    }
}
