/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Silla {
    GL gl;
    GLUT glut; 
    Cilindro barril,barr1,barr3;


    public Silla(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
    }
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        
        barril=new Cilindro(gl, glut, 1.5f, 3, 8, 1, 0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        barril.Display3(90,0, 8, 0, 0);
        
        
        barr1=new Cilindro(gl, glut, 1.55f, 0.3f, 20, 1, 0.05f, 0.05f, 0.15f);
        barr1.Display(90, 0, 8, -0.4f, 0);
        barr3=new Cilindro(gl, glut, 1.55f, 0.3f, 20, 1, 0.05f, 0.05f, 0.15f);
        barr3.Display(90, 0, 8, -2.3f, 0);
        
        gl.glPopMatrix();
}
}
