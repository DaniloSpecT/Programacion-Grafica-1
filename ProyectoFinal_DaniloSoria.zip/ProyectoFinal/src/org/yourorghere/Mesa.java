/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Mesa {
    GL gl;
    GLUT glut; 
    Cilindro mesa,mesa1,mesa2,mesa3;
    Cilindro sal1,sal2,sal3,sal4,sal5,sal6,sal7,sal8;

    public Mesa(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
    }
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        
        mesa =new Cilindro(gl, glut, 0.5f, 6, 20, 4, 0.3f, 0.3f, 0.3f);
        mesa.Display(90,0, 0, 1, 0);
        mesa1 =new Cilindro(gl, glut, 4.5f, 0.6f, 30, 1, 1, 0, 0);
        mesa1.Display(90,0, 0, 1.7f, 0);
        mesa2 =new Cilindro(gl, glut, 3f, 0.6f, 30, 1, 1, 1, 0);
        mesa2.Display(90,0, 0, 1.73f, 0);
        mesa3 =new Cilindro(gl, glut, 1.5f, 0.6f, 30, 1,0.078f, 0.588f, 0.773f);
        mesa3.Display(90,0, 0, 1.75f, 0);
        
        sal1=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal1.Display(0,0,0, 1.42f, 4);
        sal2=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal2.Display(0,0,0, 1.42f, -6);
        sal3=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal3.Display(0,90,4, 1.42f, 0);
        sal4=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal4.Display(0,90,-6, 1.42f,0 );
        sal5=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal5.Display(0,45,-4.5f,1.42f,-4.5f );
        sal6=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal6.Display(0,45,3f, 1.42f, 3f);
        sal7=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal7.Display(0,-45,4f, 1.42f, -4);
        sal8=new Cilindro(gl, glut, 0.25f, 2, 8, 4, 1, 0, 0);
        sal8.Display(0,-45,-3, 1.42f, 3);    
        
        gl.glPopMatrix();
}
}
