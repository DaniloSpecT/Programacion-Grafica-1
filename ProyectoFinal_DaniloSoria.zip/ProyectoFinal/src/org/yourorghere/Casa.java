/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Casa {
    GL gl;
    GLUT glut;
    Cilindro bloque,ca1,ca2,cd1,cd2;
    Cilindro ventana1;
    Torus ventana2;
    Puerta puerta;
    

    public Casa(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
    }
   
    public void Display(float anglex,float angley,float anglez,float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(anglex, 1, 0, 0);
        gl.glRotatef(angley, 0, 1, 0);
        gl.glRotatef(anglez, 0, 0, 1);
        gl.glScalef(Sx, Sy, Sz);
        this.bloque=new Cilindro(gl,glut,1.5,5,30,1,0.5f, 0.5f, 0.6f);
        bloque.Display(90,0, 0, 2, 0);
        this.ca1=new Cilindro(gl,glut,0.3,1,30,1,0.56f, 0.56f, 0.67f);
        ca1.Display(80,0, 0, 2.8f, 0);
        this.ca2=new Cilindro(gl,glut,0.3,0.7f,30,1,0.6f, 0.6f, 0.7f);
        ca2.Display(90,0, 0f, 3.4f, 0f);
        this.cd1=new Cilindro(gl,glut,0.3,1,30,1,0.6f, 0.6f, 0.7f);
        cd1.Display(0,0, 0, 0f, 1.5f);
        this.cd2=new Cilindro(gl,glut,0.3,1,30,1,0.56f, 0.56f, 0.67f);
        cd2.Display(90,0, 0f, 1f, 2.3f);
        this.ventana1=new Cilindro(gl,glut,0.4,0.2f,30,1,0.6f, 0.6f, 0.7f);
        
        ventana1.Display(0,65, -1.55f, 0.4f, -0.5f);
        
        puerta=new Puerta(gl,glut);
        puerta.Display(0.3f, 0.3f, 0.3f, -0.95f, -2, 2);
        gl.glPopMatrix();
        
    }
}
