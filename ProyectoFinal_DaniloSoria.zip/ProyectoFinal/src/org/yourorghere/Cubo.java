/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Cubo {
    
    GL gl;
    float x,y,z;
    float rx,ry,rz;
    float w,h,d;
    float r,g,b,a;
    GLUT glut=new GLUT();

    public Cubo(GL gl, float x, float y, float z, float rx, float ry, float rz, float w, float h, float d, float r, float g, float b) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.w = w;
        this.h = h;
        this.d = d;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public Cubo(GL gl, float x, float y, float z, float rx, float ry, float rz, float w, float h, float d, float r, float g, float b, float a) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.w = w;
        this.h = h;
        this.d = d;
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }
    
    public void display(){
        gl.glPushMatrix();
        gl.glColor3f(this.r, this.g,this.b);
        gl.glTranslatef(this.x, this.y, this.z);
        gl.glRotatef(this.rx, 1, 0, 0);
        gl.glRotatef(this.ry, 0, 1, 0);
        gl.glRotatef(this.rz, 0, 0, 1);
        gl.glScalef(this.w, this.h, this.d);
        gl.glBegin(GL.GL_QUADS);
        //Cara Frontal
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Derecha
            
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(1,-1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Trasera
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(1,-1,1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Izquierda
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(-1,-1,-1);
            gl.glVertex3f(-1,-1,1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Superior
        gl.glColor3f(this.r+0.15f, this.g+0.15f,this.b+0.15f);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Inferior
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();
        gl.glPopMatrix();
    }
    public void displayRot(){
       gl.glPushMatrix();
       gl.glEnable(GL.GL_BLEND);// you enable blending function
        gl.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA);
        gl.glColor4f(this.r, this.g,this.b,this.a);
        gl.glTranslatef(this.x, this.y, this.z);
        gl.glRotatef(this.rx, 1, 0, 0);
        gl.glRotatef(this.ry, 0, 1, 0);
        gl.glRotatef(this.rz, 0, 0, 1);
        gl.glScalef(this.w, this.h, this.d);
        gl.glBegin(GL.GL_QUADS);
        //Cara Frontal
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Derecha
            //gl.glColor4f(this.r+0.15f, this.g+0.15f,this.b+0.15f,a);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(1,-1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Trasera
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(1,-1,1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Izquierda
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(-1,-1,-1);
            gl.glVertex3f(-1,-1,1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Superior
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Inferior
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();
        gl.glDisable(GL.GL_BLEND);
        gl.glPopMatrix();
    }
    public void display2(){
        gl.glPushMatrix();
        gl.glColor3f(this.r, this.g,this.b);
        gl.glTranslatef(this.x, this.y, this.z);
        gl.glRotatef(this.rx, 1, 0, 0);
        gl.glRotatef(this.ry, 0, 1, 0);
        gl.glRotatef(this.rz, 0, 0, 1);
        gl.glScalef(this.w, this.h, this.d);
        gl.glBegin(GL.GL_QUADS);
        //Cara Frontal
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Derecha
            gl.glPushMatrix();
            gl.glColor3f(this.r-0.05f, this.g-0.05f,this.b-0.05f);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(1,-1,-1);
            gl.glPopMatrix();
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Trasera
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(1,-1,1);
        gl.glEnd();    
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Izquierda
            gl.glColor3f(this.r-0.05f, this.g-0.05f,this.b-0.05f);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(-1,-1,-1);
            gl.glVertex3f(-1,-1,1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Superior
        gl.glColor3f(this.r+0.15f, this.g+0.15f,this.b+0.15f);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Inferior
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();
        gl.glPopMatrix();
    }
    public void display3(){
        gl.glPushMatrix();
        gl.glColor3f(this.r, this.g,this.b);
        gl.glTranslatef(this.x, this.y, this.z);
        gl.glRotatef(this.rx, 1, 0, 0);
        gl.glRotatef(this.ry, 0, 1, 0);
        gl.glRotatef(this.rz, 0, 0, 1);
        gl.glScalef(this.w, this.h, this.d);
        
        gl.glBegin(GL.GL_QUADS);
        //Cara Superior
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Inferior
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Izquierda
            gl.glColor3f(this.r+0.15f, this.g+0.15f,this.b+0.15f);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(-1,-1,-1);
            gl.glVertex3f(-1,-1,1);
        gl.glEnd();
         gl.glBegin(GL.GL_QUADS);
        //Cara Lateral Derecha
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(1,-1,1);
            gl.glVertex3f(1,-1,-1);
        gl.glEnd();
        gl.glBegin(GL.GL_QUADS);
         //Cara Frontal
            gl.glVertex3f(-1,1,-1);
            gl.glVertex3f(1,1,-1);
            gl.glVertex3f(1,-1,-1);
            gl.glVertex3f(-1,-1,-1);
        gl.glEnd();   
        gl.glBegin(GL.GL_QUADS);
        //Cara Trasera
            gl.glVertex3f(1,1,1);
            gl.glVertex3f(-1,1,1);
            gl.glVertex3f(-1,-1,1);
            gl.glVertex3f(1,-1,1);
        gl.glEnd();    
        gl.glPopMatrix();
    }
}
