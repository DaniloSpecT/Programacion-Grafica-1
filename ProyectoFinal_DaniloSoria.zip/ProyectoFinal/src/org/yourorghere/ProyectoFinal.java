package org.yourorghere;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;


/**
 * ProyectoFinal.java 
 */
public class ProyectoFinal implements GLEventListener,KeyListener  {

    int ncam=0;
    int radio=100;
    float angulo=0;
    Cilindro cil1;
    Disco disk1;
    float transx=100,transy=100,transz=-100;
    Casa cas1,cas2,cas3,cas4,cas5,cas6;
    kkexterior kk;
    kkinterior kk1;
    Carretera car;
    Bob bob;
    float t=0;
    Cubo Terreno;
    Parrilla parrilla;
    Cono c;
   
    public static void main(String[] args) {
        Frame frame = new Frame("Simple JOGL Application");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new ProyectoFinal());
        frame.add(canvas);
        frame.setSize(640, 480);
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));
        GLUT glut = new GLUT();
        GL gl = drawable.getGL();
        GLU glu=new GLU();
        gl.glEnable(GL.GL_DEPTH_TEST);
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);
        
        Terreno =new Cubo(gl, 0, -13, 0, 0, 0, 0, 100, 10, 100, 0.92f,0.84f,0.79f);
        cas1=new Casa(gl,glut);
        cas2=new Casa(gl,glut);
        cas3=new Casa(gl,glut);
        cas4=new Casa(gl,glut);
        cas5=new Casa(gl,glut);
        cas6=new Casa(gl,glut);
        car=new Carretera(gl);
        kk1=new kkinterior(gl,glut);
        kk=new kkexterior(gl,glut,glu);
        parrilla=new Parrilla(gl,glut);
        c=new Cono(gl,glut);
        bob=new Bob(gl,glut,2,0,-45,0);
        // Setup the drawing area and shading mode
        gl.glClearColor(0.1f, 0.5f, 1f, 0.0f);
        gl.glShadeModel(GL.GL_SMOOTH); // try setting this to GL_FLAT and see what happens.
        drawable.addKeyListener(this);
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!
        
            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        
        glu.gluPerspective(60.0f, h, 1.0, 400.0);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();
        GLU glu=new GLU();
        GLUT glut=new GLUT();
        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();
        
        // Move the "drawing cursor" around
        gl.glTranslatef(0, 0, -20f);
        
       
        if (ncam==1) {
            glu.gluLookAt((radio*Math.sin(angulo)),20,(radio*Math.cos(angulo)),0,0,0,0,1,0);
        }
        if (ncam==2) {
             glu.gluLookAt(transx, transy, transz, 0, 0, 0, 0, 1, 0);
        }
        if (ncam==3) {
            glu.gluLookAt(bob.Tx-14.95f, bob.Ty+1f, bob.Tz, bob.Tx-15-bob.angle, 1, bob.Tz-bob.angle, 0, 1, 0);
        }
        if (ncam==4) {
            glu.gluLookAt(-46, -1.5f, -40,-49, -3, -30, 0, 1, 0);
        }
        
        if (ncam==5) {
            glu.gluLookAt(-50.1f, -2.4f, -36.5,-49, -3, -35f-t, 0, 1, 0);
        }
        
        if (ncam==6) {
            glu.gluLookAt(0, 5, -45,-30, 2, -45f-t, 0, 1, 0);
        }
        
        angulo+=0.001f;

        //Terreno
        Terreno.display();
        c.display();
        //Casas
        cas1.Display(0, -90, 0, 4.5f,4.5f,4.5f,80,9.5f,70);
        cas2.Display(0, -90, 0, 4.5f,4.5f,4.5f,50,9.5f,70);
        cas3.Display(0, -90, 0, 4.5f,4.5f,4.5f,20,9.5f,70);
        cas4.Display(0, 90, 0, 4.5f,4.5f,4.5f,80,9.5f,30);
        cas5.Display(0, 90, 0, 4.5f,4.5f,4.5f,50,9.5f,30);
        cas6.Display(0, 90, 0, 4.5f,4.5f,4.5f,20,9.5f,30);
        
        //Carretera
        car.Display();
        //Avatar
        bob.Display(0.5f, 0.5f, 0.5f);
        //Crustaceo
        kk1.Display(1, 1, 1, -50, 0, -30);
        parrilla.Display(1, 1, 1, -50, 0, -30);
        kk.Display(2,2,2,-50,3.1f,-30);

        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode()==KeyEvent.VK_RIGHT) {
            transx=transx+5f;
            System.out.println(transx+transy+transz);
        }
        if (e.getKeyCode()==KeyEvent.VK_LEFT) {
            transx=transx-5f;
            System.out.println(transx+transy+transz);
        }if (e.getKeyCode()==KeyEvent.VK_UP) {
            transy=transy+5f;
            System.out.println(transx+transy+transz);
        }if (e.getKeyCode()==KeyEvent.VK_DOWN) {
            transy=transy-5f;
            System.out.println(transx+transy+transz);
        }if (e.getKeyCode()==KeyEvent.VK_W) {
            transz=transz+5f;
            System.out.println(transx+transy+transz);
        }if (e.getKeyCode()==KeyEvent.VK_S) {
            transz=transz-5f;
            System.out.println(transx+transy+transz);
        }
        
         if (e.getKeyCode()==KeyEvent.VK_I) {
            bob.Tx=bob.Tx-1f;
        }
         if(e.getKeyCode()==KeyEvent.VK_K){
            bob.Tx=bob.Tx+1f;
        }
          if(e.getKeyCode()==KeyEvent.VK_J){
            bob.Tz=bob.Tz+1f;
        }
           if(e.getKeyCode()==KeyEvent.VK_L){
            bob.Tz=bob.Tz-1f;
        }
           if (e.getKeyCode()==KeyEvent.VK_U) {
            bob.angle=bob.angle-0.1f;
        }
         if(e.getKeyCode()==KeyEvent.VK_O){
            bob.angle=bob.angle+0.1f;
        }
         
         if(e.getKeyCode()==KeyEvent.VK_X){
            t=t+0.1f;
        }
         
         if (e.getKeyCode()==KeyEvent.VK_Z) {
             System.out.println(bob.Tx +"x"+" "+bob.Ty +"y"+" "+bob.Tz +"z");
        }
        
        
        if (e.getKeyCode()==KeyEvent.VK_1) {
            ncam=1;
        }
         if(e.getKeyCode()==KeyEvent.VK_2){
            ncam=2;
        }
          if(e.getKeyCode()==KeyEvent.VK_3){
            ncam=3;
        }
           if(e.getKeyCode()==KeyEvent.VK_4){
            ncam=4;
        }
            if(e.getKeyCode()==KeyEvent.VK_5){
            ncam=5;
        }
              if(e.getKeyCode()==KeyEvent.VK_6){
            ncam=6;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
