/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Parrilla {

    GL gl;
    GLUT glut;
    Cubo parrilla,parrilla2,parrilla3;
    Cilindro perilla1,perilla2,perilla3;
    Cubo meson1,meson2;
    public Parrilla(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
        
        parrilla=new Cubo(gl,-3.5f,-2f,-17f,0,0,0,1.3f,1f,1.5f,0.1f, 0.14f, 0.16f);
        parrilla2=new Cubo(gl,-3.95f,-0.9f,-17f,0,0,0,0.85f,0.1f,1.5f,0f, 0, 0f);
        parrilla3=new Cubo(gl,-2.5f,-1f,-17f,0,0,0,0.6f,1.3f,1.5f,0.1f, 0.14f, 0.16f);
        
        meson1=new Cubo(gl,-8.9f,-2f,-12.6f,0,0,0,1.6f,1f,1f,0.1f, 0.16f, 0.16f);
        meson2=new Cubo(gl,-3.5f,-2f,-17f,0,0,0,1.3f,1f,1.5f,0.1f, 0.1f, 0.1f);
        
        perilla1=new Cilindro(gl, glut, 0.12f, 0.1f, 10, 10, 0.2f, 0.2f, 0.2f);
        perilla2=new Cilindro(gl, glut, 0.12f, 0.1f, 10, 10, 0.2f, 0.2f, 0.2f);
        perilla3=new Cilindro(gl, glut, 0.12f, 0.1f, 10, 10, 0.2f, 0.2f, 0.2f);
    }
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
            
        parrilla.display2();
        parrilla2.display2();
        parrilla3.display2();
        
        meson1.display2();
        
        perilla1.Display2(0, 90, -4.9f, -1.5f, -16);
        perilla2.Display2(0, 90, -4.9f, -1.5f, -17);
        perilla3.Display2(0, 90, -4.9f, -1.5f, -18);
        
        gl.glPopMatrix();
        
    }

}
