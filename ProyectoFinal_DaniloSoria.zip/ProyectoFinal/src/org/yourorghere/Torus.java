/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Torus {
    GL gl;
    GLUT glut;
    double ri,re;
    int sl,ani;
    float r,g,b;

    public Torus(GL gl, GLUT glut, double ri, double re, int sl, int ani, float r, float g, float b) {
        this.gl = gl;
        this.glut = glut;
        this.ri = ri;
        this.re = re;
        this.sl = sl;
        this.ani = ani;
        this.r = r;
        this.g = g;
        this.b = b;
    }
    public void Display(float angle,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(angle, 1, 0, 0);
        gl.glColor3f(r, g, b);
        glut.glutSolidTorus(ri, re, sl, ani);
        gl.glPopMatrix();
        
    }
    public void Display2(float anglex,float angley,float Sx, float Sy, float Sz,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        gl.glRotatef(anglex, 1, 0, 0);
        gl.glRotatef(angley, 0, 1, 0);
        gl.glColor3f(r, g, b);
        glut.glutSolidTorus(ri, re, sl, ani);
        gl.glPopMatrix();
}}


