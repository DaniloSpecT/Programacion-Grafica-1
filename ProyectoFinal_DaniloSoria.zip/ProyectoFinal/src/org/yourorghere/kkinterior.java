/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class kkinterior {
    GL gl;
    GLUT glut;

    public kkinterior(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
    }
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        Cubo paredIntPrin1 =new Cubo(gl,-2f,-1f,-17f,0,0,0,0.2f,1.8f,1f,0.8f, 0.8f, 0.9f);
        paredIntPrin1.display();
        Cubo paredIntPrin2 =new Cubo(gl,-2f,4f,-17f,0,0,0,0.2f,1.5f,1f,0.8f, 0.8f, 0.9f);
        paredIntPrin2.display();
        Cubo paredIntPrin3 =new Cubo(gl,-2f,1f,-9f,0,0,0,0.2f,4.5f,7.1f,0.8f, 0.8f, 0.9f);
        paredIntPrin3.display();
        Cubo paredIntPrin4 =new Cubo(gl,-2f,1f,-23f,0,0,0,0.2f,4.5f,5.1f,0.8f, 0.8f, 0.9f);
        paredIntPrin4.display();
        Cubo tejado1=new Cubo(gl,-7.9f,5.6f,-15f,0,0,0,6.1f,0.1f,13f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        tejado1.display();
        
        Cubo paredvent1 =new Cubo(gl,-2f,2.5f,-17f,0,0,0,0.3f,0.1f,1f,0.3f, 0.3f, 0.3f);
        paredvent1.display();
        Cubo paredvent2 =new Cubo(gl,-2f,0.9f,-17f,0,0,0,0.3f,0.1f,1f,0.3f, 0.3f, 0.3f);
        paredvent2.display();
        Cubo paredvent3 =new Cubo(gl,-2f,1.7f,-16.1f,0,0,0,0.3f,0.9f,0.1f,0.3f, 0.3f, 0.3f);
        paredvent3.display();
        Cubo paredvent4 =new Cubo(gl,-2f,1.7f,-18f,0,0,0,0.3f,0.9f,0.1f,0.3f, 0.3f, 0.3f);
        paredvent4.display();
        
        Cubo Letrero1 =new Cubo(gl,0f,3.8f,-17f,0,0,0,0.3f,0.6f,1.1f,0f, 0.35f, 0f);
        Letrero1.display();
        Cubo Letrero =new Cubo(gl,0f,3.8f,-12f,0,0,0,0.3f,1f,1.5f,0.75f, 0.55f, 0f);
        Letrero.display();
        
        Cubo soga =new Cubo(gl,0f,6.8f,-17.5f,0,0,0,0.05f,2.5f,0.05f,0.522f+0.15f, 0.459f+0.15f, 0.329f+0.15f);
        Cubo soga2 =new Cubo(gl,0f,6.8f,-16.5f,0,0,0,0.05f,2.5f,0.05f,0.522f+0.15f, 0.459f+0.15f, 0.329f+0.15f);
        Cubo soga3 =new Cubo(gl,0f,6.8f,-13f,0,0,0,0.05f,2.5f,0.05f,0.522f+0.15f, 0.459f+0.15f, 0.329f+0.15f);
        Cubo soga4 =new Cubo(gl,0f,6.8f,-11f,0,0,0,0.05f,2.5f,0.05f,0.522f+0.15f, 0.459f+0.15f, 0.329f+0.15f);
        soga.display();
        soga2.display();
        soga3.display();
        soga4.display();
        

        
        Cubo tejadoInt=new Cubo(gl,0f,8.5f,-15f,0,0,0,13f,0.1f,13f,0.322f, 0.259f, 0.129f);
        tejadoInt.display();
        Cubo paredCoci =new Cubo(gl,-8f,1f,-22.2f,0,0,0,6f,4.5f,0.2f,0.188f-0.15f, 0.427f-0.15f, 0.204f-0.15f);
        paredCoci.display();
        Cubo paredOfi2 =new Cubo(gl,-8f,1f,-11.8f,0,0,0,6f,4.5f,0.2f,0.188f-0.15f, 0.427f-0.15f, 0.204f-0.15f);
        paredOfi2.display();
        Cubo paredOfi1 =new Cubo(gl,-8f,1f,-2.2f,0,0,0,6f,4.5f,0.2f,0.188f-0.15f, 0.427f-0.15f, 0.204f-0.15f);
        paredOfi1.display();
        Cubo paredBan =new Cubo(gl,-8f,1f,-27.8f,0,0,0,6f,4.5f,0.2f,0.188f-0.15f, 0.427f-0.15f, 0.204f-0.15f);
        paredBan.display();
        
        Cubo escritorioOfi =new Cubo(gl,-9f,-1.5f,-7f,0,0,0,1.3f,1f,2.2f,0.222f, 0.259f, 0.329f);
        escritorioOfi.display();
        Cubo escritorioOfi1 =new Cubo(gl,-9f,-1.5f,-8.5f,0,0,0,1.5f,1.1f,0.1f,0.422f, 0.459f, 0f);
        escritorioOfi1.display();
        Cubo escritorioOfi2 =new Cubo(gl,-9f,-1.5f,-5.6f,0,0,0,1.5f,1.1f,0.1f,0.422f, 0.459f, 0f);
        escritorioOfi2.display();
        gl.glPopMatrix();
    }
}
