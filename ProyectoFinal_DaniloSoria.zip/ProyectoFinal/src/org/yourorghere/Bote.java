/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Bote {
    GL gl;
    GLUT glut;
    Cubo boteLaterali1,boteLaterali2,boteLaterali3,boteLaterali11,boteLaterali22,boteLaterali33,boteLaterali111,boteLaterali222,boteLaterali333;
    Cubo boteLaterald1,boteLaterald2,boteLaterald3,boteLaterald11,boteLaterald22,boteLaterald33,boteLaterald111,boteLaterald222,boteLaterald333;
    Cubo boteFront1,botePiso,botePiso2,boteLaterali44,boteLaterald44;
    public Bote(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
        boteLaterali1 =new Cubo(gl,0f,1f,-13f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali2 =new Cubo(gl,0f,0.4f,-13.3f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali3 =new Cubo(gl,0f,-0.3f,-13.6f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald1 =new Cubo(gl,0f,1f,-17f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald2 =new Cubo(gl,0f,0.4f,-16.7f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald3 =new Cubo(gl,0f,-0.3f,-16.4f,0,0,0,2f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali11 =new Cubo(gl,2.8f,1f,-13.4f,0,25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali22 =new Cubo(gl,2.8f,0.4f,-13.7f,0,25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali33 =new Cubo(gl,2.8f,-0.3f,-14f,0,25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald11 =new Cubo(gl,2.8f,1f,-16.6f,0,-25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald22 =new Cubo(gl,2.8f,0.4f,-16.3f,0,-25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald33 =new Cubo(gl,2.8f,-0.3f,-16.0f,0,-25,0,1f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali111 =new Cubo(gl,3.9f,1f,-14.2f,0,60,0,0.6f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali222 =new Cubo(gl,3.7f,0.4f,-14.3f,0,60,0,0.5f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterali333 =new Cubo(gl,3.6f,-0.3f,-14.6f,0,70,0,0.5f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald111 =new Cubo(gl,3.75f,1f,-15.9f,0,-60,0,0.6f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald222 =new Cubo(gl,3.7f,0.4f,-15.7f,0,-60,0,0.5f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteLaterald333 =new Cubo(gl,3.6f,-0.3f,-15.4f,0,-70,0,0.5f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        boteFront1 =new Cubo(gl,3.8f,0.3f,-15f,0,0,80,1.7f,0.4f,0.3f,0.85f, 0.85f, 0.85f);
        botePiso =new Cubo(gl,0f,-1f,-15f,0,0,0,2f,0.4f,1.3f,1, 0f, 0f);
        botePiso2 =new Cubo(gl,0.5f,-1f,-15f,0,0,0,2f,0.4f,1f,1, 0f, 0f);
        boteLaterali44 =new Cubo(gl,2.8f,-1f,-14.4f,0,25,0,1f,0.4f,0.3f,1f, 0f, 0f);
        boteLaterald44 =new Cubo(gl,2.8f,-1f,-15.6f,0,-25,0,1f,0.4f,0.3f,1f, 0f, 0f);
    }
   public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        
        boteLaterali1.display();
        boteLaterali2.display();
        boteLaterali3.display();
        boteLaterald1.display();
        boteLaterald2.display();
        boteLaterald3.display();
        boteLaterali11.display();
        boteLaterali22.display();    
        boteLaterali33.display();
        boteLaterald11.display();
        boteLaterald22.display();
        boteLaterald33.display();
        boteLaterali111.display();
        boteLaterali222.display();
        boteLaterali333.display();
        boteLaterald111.display();
        boteLaterald222.display();
        boteLaterald333.display();
        boteFront1.display();
        botePiso.display();
        botePiso2.display();
        boteLaterali44.display();
        boteLaterald44.display();
        
        gl.glPopMatrix();
        
    }
}
