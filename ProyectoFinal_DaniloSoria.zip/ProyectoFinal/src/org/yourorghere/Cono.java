/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Cono {
    GL gl;
    GLUT glut;

    public Cono(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
    }
    public void display(){
    gl.glPushMatrix();
        gl.glColor3f(0.92f-0.05f,0.84f-0.05f,0.79f-0.05f);
        gl.glTranslatef(50, -20, -40);
        gl.glRotatef(-90, 1, 0, 0);
        glut.glutSolidCone(50, 50, 9, 30);
        gl.glPopMatrix();
        
        gl.glPushMatrix();
        gl.glColor3f(0.92f-0.05f,0.84f-0.05f,0.79f-0.05f);
        gl.glTranslatef(-50, -20, 30);
        gl.glRotatef(-90, 1, 0, 0);
        glut.glutSolidCone(50, 50, 9, 30);
        gl.glPopMatrix();
}}
