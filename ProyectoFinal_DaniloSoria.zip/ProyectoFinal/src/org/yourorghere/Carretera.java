/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Carretera {
    GL gl;
    Cubo kkr,cr,cr2;
    public Carretera(GL gl) {
        this.gl = gl;
        kkr=new Cubo(gl, -15,-3.9f , -45, 0, 0, 0, 10, 1, 6, 0.5f,0.5f,0.5f);
        cr=new Cubo(gl, -0,-3.9f , 0, 0, 0, 0, 6, 1, 100, 0.5f,0.5f,0.5f);
        cr2=new Cubo(gl, 47,-3.9f , 50, 0, 0, 0, 53, 1, 6, 0.5f,0.5f,0.5f);
    }
    public void Display(){
        gl.glPushMatrix();
        
         kkr.display3();
         cr.display3();
         cr2.display3();
        gl.glPopMatrix();
}
}
