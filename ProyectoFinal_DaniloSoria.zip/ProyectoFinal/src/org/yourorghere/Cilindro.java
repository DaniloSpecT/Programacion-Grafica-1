/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Cilindro {
    GL gl;
    GLUT glut;
    double R,h;
    int si,st;
    float r,g,b;

    public Cilindro(GL gl, GLUT glut, double R, double h, int si, int st, float r, float g, float b) {
        this.gl = gl;
        this.glut = glut;
        this.R = R;
        this.h = h;
        this.si = si;
        this.st = st;
        this.r = r;
        this.g = g;
        this.b = b;
    }
    
    
    public void Display(float anglex,float angley,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(anglex, 1, 0, 0);
        gl.glRotatef(angley, 0, 1, 0);
//        gl.glColor3f(1, 1, 1);
//        glut.glutWireCylinder(R, h, si, st);
        gl.glColor3f(r, g, b);
        glut.glutSolidCylinder(R, h, si, st);
        gl.glPopMatrix();
    }
    public void Display2(float anglex,float angley,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(anglex, 1, 0, 0);
        gl.glRotatef(angley, 0, 1, 0);
        gl.glColor3f(0, 0, 0);
        glut.glutWireCylinder(R, h, si, st);
        gl.glColor3f(r, g, b);
        glut.glutSolidCylinder(R, h, si, st);
        gl.glPopMatrix();
    }
    public void Display3(float anglex,float angley,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(anglex, 1, 0, 0);
        gl.glRotatef(angley, 0, 1, 0);
        gl.glColor3f(0, 0, 0);
        glut.glutWireCylinder(R+0.01f, h+0.01f, si, st);
        gl.glColor3f(r, g, b);
        glut.glutSolidCylinder(R, h, si, st);
        gl.glPopMatrix();
    }
}