/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Puerta {
    GL gl;
    GLUT glut;
    Cubo puertaLd,puertaLd1,puertaLd2,puertaLd3,puertaLd4,puertaLd5,puertaLi
         ,puertaLi1,puertaLi2,puertaLi3,puertaLi4,puertaLi5,puertaInt,puertaInt2;
    Cilindro ventpuerta;
    
    
    public Puerta(GL gl, GLUT glut) {
        this.gl = gl;
        this.glut = glut;
        
        puertaLd =new Cubo (gl,-2f,-1f,-8f,0,0,0,0.5f,2f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi =new Cubo (gl,-2f,-1f,-5f,0,0,0,0.5f,2f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLd1 =new Cubo (gl,-2f,1.3f,-7.9f,15,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi1 =new Cubo (gl,-2f,1.3f,-5.1f,-15,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLd2 =new Cubo (gl,-2f,1.9f,-7.6f,35,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi2 =new Cubo (gl,-2f,1.9f,-5.4f,-35,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLd3 =new Cubo (gl,-2f,2.3f,-7.2f,55,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi3 =new Cubo (gl,-2f,2.3f,-5.8f,-55,0,0,0.5f,0.4f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLd4 =new Cubo (gl,-2f,2.5f,-6.8f,70,0,0,0.5f,0.2f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi4 =new Cubo (gl,-2f,2.5f,-6.2f,-70,0,0,0.5f,0.2f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLd5 =new Cubo (gl,-2f,2.5f,-6.6f,85,0,0,0.5f,0.2f,0.2f,0.6f, 0.6f, 0.7f);
        puertaLi5 =new Cubo (gl,-2f,2.5f,-6.4f,-85,0,0,0.5f,0.2f,0.2f,0.6f, 0.6f, 0.7f);
        ventpuerta =new Cilindro (gl, glut, 0.5f, 0.8f, 20, 5, 0.6f, 0.6f, 0.7f);
        puertaInt =new Cubo(gl,-2f,-0.4f,-6.5f,0,0,0,0.3f,2.3f,1.3f,0.7f, 0.7f, 0.8f);
        puertaInt2 =new Cubo(gl,-2f,2f,-6.5f,0,0,0,0.3f,0.5f,0.8f,0.7f, 0.7f, 0.8f);
        
}
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        
        puertaLd.display();
        puertaLi.display();
        puertaLd1.display();
        puertaLi1.display();
        puertaLd2.display();
        puertaLi2.display();
        puertaLd3.display();
        puertaLi3.display();
        puertaLd4.display();
        puertaLi4.display();   
        puertaLd5.display();
        puertaLi5.display();
        ventpuerta.Display(0, 90, -2.4f, 1, -6.5f);
        puertaInt.display();
        puertaInt2.display();
        
        gl.glPopMatrix();
        
    }

}
