/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author Mamayo
 */
public class kkexterior {
    GL gl;
    GLUT glut;
    GLU glu;
    Torus li1,li2,ld1,ld2;
    Cubo cli1,cli2,cli3,cld1,cld2,cld3;
    Cubo cLi,cLd,cf1,cf2,ct;
    Cubo piso,piso1,piso2,piso3,piso4,piso5,piso6,piso7,piso8,
         piso9,piso10,piso11,piso12,piso13,piso14,piso15,piso16,piso82,
         piso92,piso102,piso112,piso122,piso132,piso142,piso152,piso162,
         piso17,piso18,piso19,piso20;
    Cubo ventanaf1,ventanaf2;
    Cubo cfli,cfld;
    Cubo ct1;
    Cubo cfs,cfs1,cfs2,cfs3,cfs4,cfs5,cfs6,cfs7;
    Disco disk2;
    Mesa mes1, mes2, mes3,mes4;
    Cubo puerta1,puerta2;
    Cilindro chimenea,poste;
    Bote bote;
    Puerta puertaOfi,puertaCoci,puertaBan,puertaCoci2;
    Silla s1,s2,s3,s4,s5,s6,s7,s8;
    public kkexterior(GL gl, GLUT glut,GLU glu) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        
        //Laterales
        //Torus
        li1=new Torus(gl,glut,1,7,20,15,0.322f, 0.259f, 0.129f);
        ld1=new Torus(gl,glut,1,7,20,15,0.322f, 0.259f, 0.129f);
        //CubosLateralesTorus
        cli1=new Cubo(gl,0f,-1f,0f,0,0,0,6f,2.5f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        cld1=new Cubo(gl,0f,-1f,-15f,0,180,0,6f,2.5f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        cli2=new Cubo(gl,0f,3.15f,0f,0,0,0,6f,1.7f,0.1f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        cld2=new Cubo(gl,0f,3.15f,-15f,0,0,0,6f,1.7f,0.1f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        cli3=new Cubo(gl,0f,5.5f,0f,0,0,0,4f,0.7f,0.1f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        cld3=new Cubo(gl,0f,5.5f,-15f,0,0,0,4f,0.7f,0.1f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        //CubosLateralesBases
        cLi=new Cubo(gl,0f,-2.5f,0f,0,0,0,8f,0.5f,1f,0.322f, 0.259f, 0.129f);
        cLd=new Cubo(gl,0f,-2.5f,-15f,0,0,0,8f,0.5f,1f,0.322f, 0.259f, 0.129f);
        //Piso
        piso=new Cubo(gl,-0.4f,-3f,-1.3f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso1=new Cubo(gl,-0.4f,-3f,-1.9f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso2=new Cubo(gl,-0.4f,-3f,-2.5f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso3=new Cubo(gl,-0.4f,-3f,-3.1f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso4=new Cubo(gl,-0.4f,-3f,-3.7f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso5=new Cubo(gl,-0.4f,-3f,-4.3f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso6=new Cubo(gl,-0.4f,-3f,-4.9f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso7=new Cubo(gl,-0.4f,-3f,-5.5f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso8=new Cubo(gl,2.5f,-3f,-6.1f,0,0,0,3.5f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso9=new Cubo(gl,2.5f,-3f,-6.7f,0,0,0,3.5f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso10=new Cubo(gl,2.5f,-3f,-7.3f,0,0,0,3.5f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso11=new Cubo(gl,2.5f,-3f,-7.9f,0,0,0,3.5f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso12=new Cubo(gl,2.5f,-3f,-8.5f,0,0,0,3.5f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso13=new Cubo(gl,2.5f,-3f,-9.1f,0,0,0,3.5f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso14=new Cubo(gl,2.5f,-3f,-9.7f,0,0,0,3.5f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso15=new Cubo(gl,2.5f,-3f,-10.3f,0,0,0,3.5f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso16=new Cubo(gl,2.5f,-3f,-10.9f,0,0,0,3.5f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso82=new Cubo(gl,-3.9f,-3f,-6.1f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        piso92=new Cubo(gl,-3.9f,-3f,-6.7f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.05f, 0.259f+0.05f, 0.129f+0.05f);
        piso102=new Cubo(gl,-3.9f,-3f,-7.3f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        piso112=new Cubo(gl,-3.9f,-3f,-7.9f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.05f, 0.259f+0.05f, 0.129f+0.05f);
        piso122=new Cubo(gl,-3.9f,-3f,-8.5f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        piso132=new Cubo(gl,-3.9f,-3f,-9.1f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.05f, 0.259f+0.05f, 0.129f+0.05f);
        piso142=new Cubo(gl,-3.9f,-3f,-9.7f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        piso152=new Cubo(gl,-3.9f,-3f,-10.3f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.05f, 0.259f+0.05f, 0.129f+0.05f);
        piso162=new Cubo(gl,-3.9f,-3f,-10.9f,0,0,0,2.9f,0.1f,0.3f,0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        piso17=new Cubo(gl,-0.4f,-3f,-11.5f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso18=new Cubo(gl,-0.4f,-3f,-12.1f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        piso19=new Cubo(gl,-0.4f,-3f,-12.7f,0,0,0,6.4f,0.1f,0.3f,0.188f, 0.427f, 0.204f);
        piso20=new Cubo(gl,-0.4f,-3f,-13.3f,0,0,0,6.4f,0.1f,0.3f,0.188f-0.1f, 0.427f-0.1f, 0.204f-0.1f);
        
        //Frontales
        //CubosBasesFrontales
        cf1=new Cubo(gl,7f,-2.5f,-3f,0,0,0,1f,0.5f,2f,0.322f, 0.259f, 0.129f);
        cf2=new Cubo(gl,7f,-2.5f,-12f,0,0,0,1f,0.5f,2f,0.322f, 0.259f, 0.129f);
        //CubosColumnasFrontales
        cfli=new Cubo(gl,7f,-0.5f,-4.5f,0,0,0,0.5f,1.7f,0.5f,0.322f, 0.259f, 0.129f);
        cfld=new Cubo(gl,7f,-0.5f,-10.5f,0,0,0,0.5f,1.7f,0.5f,0.322f, 0.259f, 0.129f);
        cfs=new Cubo(gl,7f,0.7f,-7.5f,0,0,0,0.5f,0.5f,2.5f,0.322f, 0.259f, 0.129f);
        //Tejado
        cfs1=new Cubo(gl,6.7f,2f,-7.5f,0,0,0,0.2f,0.8f,7f,0.322f+0.1f, 0.259f+0.1f, 0.129f+0.1f);
        cfs2=new Cubo(gl,5.8f,4f,-7.5f,0,0,35,0.2f,1.7f,7f,0.322f, 0.259f, 0.129f);
        cfs3=new Cubo(gl,3.7f,6f,-7.5f,0,0,60,0.2f,1.5f,7f,0.322f+0.1f, 0.259f+0.1f, 0.129f+0.1f);
        cfs4=new Cubo(gl,1f,6.9f,-7.5f,0,0,83,0.2f,1.5f,7f,0.322f, 0.259f, 0.129f);
        cfs5=new Cubo(gl,-1.8f,6.7f,-7.5f,0,0,105,0.2f,1.6f,7f,0.322f+0.1f, 0.259f+0.1f, 0.129f+0.1f);
        cfs6=new Cubo(gl,-4.4f,5.4f,-7.5f,0,0,130,0.2f,1.5f,7f,0.322f, 0.259f, 0.129f);
        cfs7=new Cubo(gl,-6.2f,3.1f,-7.5f,0,0,152,0.2f,1.7f,7f,0.322f+0.1f, 0.259f+0.1f, 0.129f+0.1f);
        //Trasera
        //CuboParedTrasera        
        ct=new Cubo(gl,-7.4f,-2.5f,-7f,0,0,0,0.6f,0.5f,7f,0.322f, 0.259f, 0.129f);
        ct1=new Cubo(gl,-7f,-0.25f,-7f,0,0,0,0.2f,1.9f,7f,0.322f, 0.259f, 0.129f );
        //Base
        disk2=new Disco (gl,glu,0,30,30,20,0.5f,0.5f,0.5f);
        //Mesas
        mes1=new Mesa (gl,glut);
        mes2=new Mesa (gl,glut);
        mes3=new Mesa (gl,glut);
        mes4=new Mesa (gl,glut);
        //Ventanas
        ventanaf1=new Cubo(gl,6.8f,-0.5f,-2.5f,0,90,0,1.7f,1.7f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        ventanaf2=new Cubo(gl,6.8f,-0.5f,-12.5f,0,90,0,1.7f,1.7f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        //Puerta
        puerta1=new Cubo(gl,7.4f,-1.35f,-5f,0,0,0,1.4f,1.7f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        puerta2=new Cubo(gl,7.4f,-1.35f,-10f,0,0,0,1.4f,1.7f,0.1f,0.125f, 0.475f, 0.878f,0.5f);
        //Poste
        
        //Chimenea
        chimenea=new Cilindro(gl, glut, 0.5f, 2, 8, 1, 0.5f, 0.5f, 0.5f);
        
        //Bote
        bote=new Bote(gl,glut);
        //Puertas
        puertaOfi=new Puerta(gl,glut);
        puertaCoci=new Puerta(gl,glut);
        puertaCoci2=new Puerta(gl,glut);
        puertaBan=new Puerta(gl,glut);
        //Sillas
        s1=new Silla(gl,glut);
        s2=new Silla(gl,glut);
        s3=new Silla(gl,glut);
        s4=new Silla(gl,glut);
        s5=new Silla(gl,glut);
        s6=new Silla(gl,glut);
        s7=new Silla(gl,glut);
        s8=new Silla(gl,glut);
        
        
    }
    
    public void Display(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        
        gl.glScalef(Sx, Sy, Sz);
        //Laterales
        //Torus
        li1.Display(0, 0, 0, 0);
        ld1.Display(0, 0, 0, -15);
        //CubosTorus
        cli2.display();
        cld2.display();
        cli3.display();
        cld3.display();
        
        //CubosBases
        cLi.display(); 
        cLd.display();
        //piso
        piso.display();
        piso1.display();
        piso2.display();
        piso3.display();
        piso4.display();
        piso5.display();
        piso6.display();
        piso7.display();
        piso8.display();
        piso9.display();
        piso10.display();
        piso11.display();
        piso12.display();
        piso13.display();
        piso14.display();
        piso15.display();
        piso16.display();
        piso82.display();
        piso92.display();
        piso102.display();
        piso112.display();
        piso122.display();
        piso132.display();
        piso142.display();
        piso152.display();
        piso162.display();
        piso17.display();
        piso18.display();
        piso19.display();
        piso20.display();
        
        //CubosBasesFrontales
        cf1.display();
        cf2.display();
        //CubosColumnasFrontales
        cfli.display();
        cfld.display();
        cfs.display();
        //Tejado
        cfs1.display();
        cfs2.display(); 
        cfs3.display();
        cfs4.display();
        cfs5.display();
        cfs6.display();
        cfs7.display();
        
        //Cubos traseros
        ct.display();
        ct1.display();
        //Base
        disk2.Display(90,0.5f,0.5f,0.5f, 0.5f, -3f, -7.2f);
        
        //Mesas
        mes1.Display(0.15f, 0.15f, 0.15f, 1.5f, -2.2f, -3.5f);
        mes2.Display(0.15f, 0.15f, 0.15f, 4.5f, -2.2f, -3.5f);
        mes3.Display(0.15f, 0.15f, 0.15f, 1.5f, -2.2f, -12);
        mes4.Display(0.15f, 0.15f, 0.15f, 4.5f, -2.2f, -12);
        
        //Chimenea
        chimenea.Display(90, 0, 0.5f, 9.2f, -7);
        
        //Bote
        bote.Display(0.4f, 0.4f, 0.4f, -0.27f, -2.4f, -2.5f);
        displayPoste(1,1,1,0,0,0);
        displayBanderas(1,1,1,0,0,0);
        
        //Puertas
        puertaOfi.Display(0.35f, 0.45f, 0.35f, -0.3f, -1.8f, -1);
        puertaCoci.Display(0.35f, 0.45f, 0.35f, -0.3f, -1.8f, -8);
        gl.glPushMatrix();
        gl.glRotatef(90, 0, 1, 0);
        puertaCoci2.Display(0.35f, 0.45f, 0.35f, 6.65f, -1.8f, 0.2f);
        gl.glPopMatrix();
        puertaBan.Display(0.35f, 0.45f, 0.35f, -0.3f, -1.8f, -11);
        displayBanderas(0.3f,0.3f,0.3f,-8.9f,-1.4f,-1);
        
        //Sillas
        s1.Display(0.2f, 0.2f, 0.2f, 2, -2.2f, -4);
        s2.Display(0.2f, 0.2f, 0.2f, 3.6f, -2.2f, -2.7f);
        s3.Display(0.2f, 0.2f, 0.2f, 2, -2.2f, -12);
        s4.Display(0.2f, 0.2f, 0.2f, 3.8f, -2.2f, -11.7f);
        s5.Display(0.2f, 0.2f, 0.2f, 0f, -2.2f, -4.5f);
        s6.Display(0.2f, 0.2f, 0.2f, 0f, -2.2f, -2.4f);
        s7.Display(0.2f, 0.2f, 0.2f, 0.6f, -2.2f, -12);
        s8.Display(0.2f, 0.2f, 0.2f, -1f, -2.2f, -11.7f);
 
        //Ventanas
        ventanaf1.displayRot();
        ventanaf2.displayRot();
          puerta1.displayRot();
          puerta2.displayRot();
        
        //LateralTorus
        cli1.displayRot();
        cld1.displayRot();
        gl.glPopMatrix();
}
    
    public void displayBanderas(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);        
        gl.glScalef(Sx, Sy, Sz);
        Cubo base,vertical,horizontal;
        Cubo base2;
        Cilindro centro;
        Cubo base3;
        Cubo base4,cuadro1,cuadro2;
        Cubo base5,mitad;
        Triangulo tri1;
        
        base=new Cubo(gl,7f,2.35f,-2.5f,-15,0,0,0.1f,0.6f,0.9f,1, 0, 0f);
        base.display();
        vertical=new Cubo(gl,7.1f,2.35f,-2.5f,-15,0,0,0.1f,0.6f,0.15f,1, 1, 0f);
        vertical.display();
        horizontal=new Cubo(gl,7.1f,2.35f,-2.5f,-15,0,0,0.1f,0.15f,0.9f,1, 1, 0f);
        horizontal.display();
        
        base2=new Cubo(gl,7f,1.9f,-5f,-5,0,0,0.1f,0.6f,0.9f,1, 1, 0f);
        base2.display();
        centro=new Cilindro(gl, glut, 0.4f, 0.2f, 10, 10, 0.1f, 0.1f, 0.1f);
        centro.Display(0, 90, 7f, 1.9f, -5f);
        
        base3=new Cubo(gl,7f,1.8f,-7.5f,0,0,0,0.1f,0.6f,0.9f,0, 0, 1f);
        base3.display();
        tri1=new Triangulo(gl,7.2f,1.3f,-8.4f,0,90,90,1.1f,1.8f,0.1f,0.9f, 0.9f, 0.9f);
        tri1.display();
        
        
        base4=new Cubo(gl,7f,1.9f,-10f,5,0,0,0.1f,0.6f,0.9f,1, 0, 0f);
        base4.display();
        cuadro1=new Cubo(gl,7.1f,2.15f,-9.5f,5,0,0,0.1f,0.3f,0.45f,1, 1, 1f);
        cuadro1.display();
        cuadro2=new Cubo(gl,7.1f,1.65f,-10.45f,5,0,0,0.1f,0.3f,0.45f,1, 1, 1f);
        cuadro2.display();
        
        base5=new Cubo(gl,7f,2.35f,-12.5f,15,0,0,0.1f,0.6f,0.9f,1, 1, 0f);
        base5.display();
        mitad=new Cubo(gl,7.1f,2.48f,-13f,15,0,0,0.1f,0.6f,0.45f,0, 0, 1f);
        mitad.display();
        gl.glPopMatrix();
    }
    
    public void displayPoste(float Sx, float Sy, float Sz, float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);        
        gl.glScalef(Sx, Sy, Sz);
        Cilindro poste1;
        Torus t1,t2,t3,t4;
        Cubo Kvertical,K1,K2;
        poste1=new Cilindro(gl, glut, 0.2f, 10, 8, 1, 0.75f, 0.55f, 0.35f);
        poste1.Display(90, 0, 15f, 7f, 4);
        t1=new Torus(gl,glut,1.2f,0.6f,8,10,0.655f, 0.565f, 0.706f);
        t1.Display2(0,90,0.3f,1f,1f, 15, 8, 4);
        t2=new Torus(gl,glut,1.2f,0.6f,8,10,0.655f, 0.565f, 0.706f);
        t2.Display2(90,0,1,0.3f,1f, 16.5f, 6.3f, 4);
        t3=new Torus(gl,glut,1.08f,0.59f,8,10,0.955f, 0.865f, 1f);
        t3.Display2(0,90,0.3f,1f,1f, 15.1f, 8, 4);
        t4=new Torus(gl,glut,1.08f,0.59f,8,10,0.955f, 0.865f, 1f);
        t4.Display2(90,0,1,0.3f,1f, 16.5f, 6.4f, 4);
        
        Kvertical=new Cubo(gl,15.4f,8f,4.2f,0,0,0,0.1f,0.8f,0.1f,1, 0, 0f);
        Kvertical.display();
        K1=new Cubo(gl,15.4f,7.7f,3.8f,45,0,0,0.1f,0.5f,0.1f,1, 0, 0f);
        K1.display();
        K2=new Cubo(gl,15.4f,8.3f,3.8f,-45,0,0,0.1f,0.5f,0.1f,1, 0, 0f);
        K2.display();
        gl.glPopMatrix();
    }
    
    
}