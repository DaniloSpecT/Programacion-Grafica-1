package org.yourorghere;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;
/**
 *
 * @author fing.labcom
 */
public class Disco {
    GL gl;
    GLU glu;
    
    double ri,re;
    int si,lo;

    public Disco(GL gl, GLU glu, double ri, double re, int si, int lo, float r, float g, float b) {
        this.gl = gl;
        this.glu = glu;
        this.ri = ri;
        this.re = re;
        this.si = si;
        this.lo = lo;
        this.r = r;
        this.g = g;
        this.b = b;
    }
    float r,g,b;
    public void Display(float angle,float Sx, float Sy, float Sz,float Tx, float Ty, float Tz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glScalef(Sx, Sy, Sz);
        gl.glRotatef(angle, 1, 0, 0);
        gl.glColor3f(1, 1, 1);
        gl.glColor3f(r, g, b);
        GLUquadric quad;
        quad=glu.gluNewQuadric();
        glu.gluDisk(quad, ri, re, si, lo);
        gl.glPopMatrix();
    }
}
