/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Bob {
    GL gl;
    GLUT glut;
    Cubo cuerpo,camisa,pantalon,det1,det2,det3,det4;
    Cilindro ojo1,ojo2,pupila1,pupila2,iris1,iris2;
    float Tx,Ty,Tz;
    float angle;

    
    public Bob(GL gl, GLUT glut,float Tx, float Ty, float Tz,float angle) {
        this.gl = gl;
        this.glut = glut;
        this.Tx = Tx;
        this.Ty = Ty;
        this.Tz = Tz;
        this.angle = angle;
        
        cuerpo=new Cubo( gl, 0, 0,0 , 0, 0, 0, 0.5f, 1, 1, 0.85f, 0.85f, 0);
        camisa=new Cubo( gl, 0, -1f,0 , 0, 0, 0, 0.5f, 0.05f, 1, 1f, 1f, 1);
        pantalon=new Cubo( gl, 0, -1.4f,0 , 0, 0, 0, 0.5f, 0.3f, 1, 0.322f+0.15f, 0.259f+0.15f, 0.129f+0.15f);
        ojo1=new Cilindro(gl,glut,-2,0.2f,0,1,1f, 1f, 1f);
    }

    
     public void Display(float Sx, float Sy, float Sz){
        gl.glPushMatrix();
        gl.glTranslatef(Tx, Ty, Tz);
        gl.glRotatef(angle, 0, 1, 0);
       
        gl.glScalef(Sx, Sy, Sz);
        
        cuerpo.display2();
        camisa.display();
        pantalon.display();
//        ojo1.Display(0, 0, 0, 0, 0);
       
        
        gl.glPopMatrix();
        
    }

}


